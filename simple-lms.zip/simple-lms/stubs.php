<?php
/**
 * Stubs for WordPress and other dependencies to suppress IDE errors.
 * This file is not loaded in the application.
 *
 * @package SimpleLMS
 */

if (!defined('ABSPATH')) {
	define('ABSPATH', __DIR__ . '/');
}

if (!defined('OBJECT')) {
	define('OBJECT', 'OBJECT');
}

define('DAY_IN_SECONDS', 86400);

// WordPress Core Functions
function add_action($hook, $callback, $priority = 10, $accepted_args = 1)
{
}
function do_action($hook, ...$arg)
{
}
function add_filter($hook, $callback, $priority = 10, $accepted_args = 1)
{
}
function apply_filters($hook, $value, ...$args)
{
	return $value;
}
function get_user_by($field, $value)
{
	return new WP_User();
}
function user_can($user, $capability)
{
	return true;
}
function get_post($post = null, $output = OBJECT, $filter = 'raw')
{
	return new WP_Post();
}
function esc_html__($text, $domain = 'default')
{
	return $text;
}
function esc_html_e($text, $domain = 'default')
{
	echo $text;
}
function esc_html($text)
{
	return $text;
}
function esc_attr($text)
{
	return $text;
}
function esc_url($url, $protocols = null, $_context = null)
{
	return $url;
}
function esc_url_raw($url, $protocols = null)
{
	return $url;
}
function get_current_user_id()
{
	return 1;
}
function wp_create_nonce($action = -1)
{
	return 'nonce';
}
function wp_verify_nonce($nonce, $action = -1)
{
	return 1;
}
function wp_nonce_field($action = -1, $name = '_wpnonce', $referer = true, $echo = true)
{
}
function rest_url($path = '')
{
	return 'http://example.com/wp-json/' . $path;
}
function wp_enqueue_script($handle, $src = '', $deps = array(), $ver = false, $in_footer = false)
{
}
function wp_enqueue_style($handle, $src = '', $deps = array(), $ver = false, $media = 'all')
{
}
function wp_localize_script($handle, $name, $data)
{
}
function get_the_title($post = 0)
{
	return 'Title';
}
function get_the_ID()
{
	return 1;
}
function do_shortcode($content, $ignore_html = false)
{
	return $content;
}
function add_shortcode($tag, $callback)
{
}
function shortcode_atts($pairs, $atts, $shortcode = '')
{
	return array();
}
function absint($maybeint)
{
	return 1;
}
function the_content($more_link_text = null, $strip_teaser = false)
{
}
function get_permalink($id = 0, $leavename = false)
{
	return 'http://example.com/post';
}
function is_user_logged_in()
{
	return true;
}
function sanitize_key($key)
{
	return $key;
}
function sanitize_text_field($str)
{
	return $str;
}
function sanitize_textarea_field($str)
{
	return $str;
}
function rest_sanitize_boolean($value)
{
	return true;
}
function remove_query_arg($key, $query = false)
{
	return '';
}
function add_query_arg($key, $value = false, $url = false)
{
	return '';
}
function selected($selected, $current = true, $echo = true)
{
}
function wp_reset_postdata()
{
}
function register_post_type($post_type, $args = array())
{
}
function register_post_meta($post_type, $meta_key, $args = array())
{
}
function register_taxonomy($taxonomy, $object_type, $args = array())
{
}
/** @return int|\WP_Error */
function wp_insert_post($postarr, $wp_error = false)
{
	return 1;
}
/** @return array|\WP_Error */
function wp_insert_term($term, $taxonomy, $args = array())
{
	return array();
}
function wp_set_post_terms($post_id, $tags = '', $taxonomy = 'post_tag', $append = false)
{
}
/** @return array|\WP_Error */
function wp_get_post_terms($post_id, $taxonomy = 'post_tag', $args = array())
{
	return array();
}
function get_page_by_title($page_title, $output = OBJECT, $post_type = 'page')
{
	return new WP_Post();
}
/** @param mixed $thing @return bool */
function is_wp_error($thing)
{
	return $thing instanceof WP_Error;
}
function wp_die($message = '', $title = '', $args = array())
{
}
function wp_redirect($location, $status = 302, $x_redirect_by = 'WordPress')
{
	return true;
}
function admin_url($path = '', $scheme = 'admin')
{
	return '';
}
function current_user_can($capability, ...$args)
{
	return true;
}
function get_post_status($post = null)
{
	return 'publish';
}
function __($text, $domain = 'default')
{
	return $text;
}
function _e($text, $domain = 'default')
{
	echo $text;
}
function wp_next_scheduled($hook, $args = array())
{
	return false;
}
function wp_schedule_event($timestamp, $recurrence, $hook, $args = array())
{
}
function add_meta_box($id, $title, $callback, $screen = null, $context = 'advanced', $priority = 'default', $callback_args = null)
{
}
function add_menu_page($page_title, $menu_title, $capability, $menu_slug, $function = '', $icon_url = '', $position = null)
{
}
function add_submenu_page($parent_slug, $page_title, $menu_title, $capability, $menu_slug, $function = '')
{
}
function wp_list_pluck($list, $field, $index_key = null)
{
	return array();
}
function wp_delete_post($postid, $force_delete = false)
{
}
function register_rest_route($namespace, $route, $args = array(), $override = false)
{
}
function rest_ensure_response($response)
{
	return new WP_REST_Response();
}
function get_userdata($user_id)
{
	return new WP_User();
}
function wp_unslash($value)
{
	return $value;
}
function delete_user_meta($user_id, $meta_key, $meta_value = '')
{
	return true;
}
function update_user_meta($user_id, $meta_key, $meta_value, $prev_value = '')
{
	return true;
}
function get_user_meta($user_id, $key = '', $single = false)
{
	return '';
}
function get_post_meta($post_id, $key = '', $single = false)
{
	return '';
}
function update_post_meta($post_id, $meta_key, $meta_value, $prev_value = '')
{
	return true;
}
function get_option($option, $default = false)
{
	return $default;
}
function date_i18n($dateformatstring, $unixtimestamp = false, $gmt = false)
{
	return '';
}
function current_time($type, $gmt = 0)
{
	return '';
}
function dbDelta($queries, $execute = true)
{
	return array();
}
function plugin_dir_path($file)
{
	return __DIR__ . '/';
}
function plugin_dir_url($file)
{
	return 'http://example.com/wp-content/plugins/plugin/';
}
function plugin_basename($file)
{
	return 'plugin/plugin.php';
}
function flush_rewrite_rules($hard = true)
{
}
function register_activation_hook($file, $function)
{
}
function register_deactivation_hook($file, $function)
{
}
function get_current_screen()
{
	return new WP_Screen();
}
function get_posts($args = null)
{
	return array();
}
function maybe_unserialize($data)
{
	return $data;
}
function maybe_serialize($data)
{
	return $data;
}
function is_serialized($data, $strict = true)
{
	return false;
}
function is_serialized_string($data)
{
	return false;
}

// WordPress Classes
class WP_User
{
	public $ID = 1;
	public $user_login = 'user';
	public $display_name = 'User';
	public $user_email = 'user@example.com';
	public $roles = array();
	public function exists()
	{
		return true;
	}
}
class WP_Post
{
	public $ID = 1;
	public $post_title = 'Title';
	public $post_type = 'post';
	public $post_content = 'Content';
}
class WP_Query
{
	public $posts = array();
	public $found_posts = 0;
	public function __construct($args = array())
	{
	}
	public function have_posts()
	{
		return true;
	}
}
class WP_User_Query
{
	public $results = array();
	public function __construct($args = null)
	{
	}
	public function get_results()
	{
		return array();
	}
	public function get_total()
	{
		return 1;
	}
}
class WP_REST_Request
{
	public function get_param($key)
	{
		return '';
	}
	public function has_param($key)
	{
		return true;
	}
	public function get_header($header)
	{
		return '';
	}
}
class WP_REST_Response
{
	public function set_status($code)
	{
	}
	public function get_data()
	{
		return array();
	}
}
class WP_Error
{
	public $error_data = array();
	public function __construct($code = '', $message = '', $data = '')
	{
	}
	public function get_error_message()
	{
		return '';
	}
	public function get_error_data($code = '')
	{
		return '';
	}
}
class WP_Screen
{
	public $id = 'base';
	public $post_type = 'post';
}

// Beaver Builder Classes
class FLBuilderCSS
{
	public static function rule($args)
	{
	}
}
class FLBuilderModule
{
	public function __construct($params)
	{
	}
}
class FLBuilder
{
	public static function register_module($module, $args)
	{
	}
}
class FLBuilderModel
{
	public static function is_builder_active()
	{
		return false;
	}
}

// Gravity Forms
function rgar($array, $name, $default = '')
{
	return '';
}
class GFAPI
{
	public static function get_entry($entry_id)
	{
		return array();
	}
	public static function get_form($form_id)
	{
		return array();
	}
	public static function get_entries($form_id, $search_criteria = array(), $sorting = null, $paging = null, &$total_count = null)
	{
		return array();
	}
	public static function add_entry($entry)
	{
		return 1;
	}
	public static function get_forms($active = true, $trash = false, $sort_column = 'title', $sort_dir = 'ASC')
	{
		return array();
	}
}

// PMPro
function pmpro_getAllLevels($return_array = false, $order = true)
{
	return array();
}
function pmpro_getLevel($level_id)
{
	return new stdClass();
}
function pmpro_hasMembershipLevel($levels = [], $user_id = null)
{
	return true;
}
class PMPro_Group_Account
{
	public static function get_groups_by_owner($user_id)
	{
		return array();
	}
}
function pmprogroupacct_get_members_for_group($group_id)
{
	return array();
}